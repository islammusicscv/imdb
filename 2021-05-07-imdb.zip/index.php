<?php
    include_once "header.php";
?>
    <h1>Dobrodošli na strani INDEX</h1>
<?php
    include_once "footer.php";
?>